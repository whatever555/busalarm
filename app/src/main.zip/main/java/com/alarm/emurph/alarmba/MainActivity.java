package com.alarm.emurph.alarmba;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String FILENAME = "data.json";
        String string = "";

        writeToFile(FILENAME, "[{\"label\":\"Everyday Alarm\",\"days_string\":\"MON,TUE,WED,THU,FRI\", \"start_time\":\"1:00\",\"end_time\":\"1:15\",\"buses\":[\"14\",\"15\"],\"stops\":[\"667\"]},{\"label\":\"Weekend Alarm\", \"start_time\":\"2:00\",\"days_string\":\"SAT,SUN\",\"end_time\":\"1:15\",\"buses\":[\"14\",\"15\"],\"stops\":[\"667\"]}]");

        String jsonString = readFromFile(FILENAME);

        setContentView(R.layout.activity_main);



        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        View view;
        // Layout inflater
        LayoutInflater layoutInflater;

        System.out.println(jsonString);
        try {
            String alarmLabel;
            String start_time;
            String end_time;
            JSONArray buses;
            JSONArray stops;
            System.out.println(jsonString);
            JSONArray array = new JSONArray(jsonString);
            for (int i = 0; i < array.length(); i++) {

                // Parent layout
                int resID = getResources().getIdentifier("layout"+i, "id", getPackageName());
                RelativeLayout parentLayout = ((RelativeLayout) findViewById(resID));

                layoutInflater = getLayoutInflater();
                System.out.println("LOOPING");
                JSONObject row = array.getJSONObject(i);
                start_time = row.getString("start_time");
                end_time = row.getString("end_time");
                alarmLabel = row.getString("label");
                String daysString = row.getString("days_string");
                buses = new JSONArray(row.getString("buses"));
                stops = new JSONArray(row.getString("stops"));

                System.out.println("start_time" + start_time);
                // Add the text layout to the parent layout
                view = layoutInflater.inflate(R.layout.alarm_entry, parentLayout, false);

                // In order to get the view we have to use the new view with text_layout in it
                TableLayout alarmView = (TableLayout)view.findViewById(R.id.alarmView);

                TextView labelText = (TextView)view.findViewById(R.id.alarmLabel);
                labelText.setText(alarmLabel);
                TextView timeDetailsText = (TextView)view.findViewById(R.id.timeDetails);
                timeDetailsText.setText("From: " + start_time + " to " + end_time + " on days: " + daysString);


                // Add the text view to the parent layout
                parentLayout.addView(alarmView);
            }
        }
        catch (JSONException e) {

        }
    }


    public String readFromFile(String FILENAME) {

        String ret = "";

        try {
            InputStream inputStream = openFileInput(FILENAME);

            if ( inputStream != null ) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ( (receiveString = bufferedReader.readLine()) != null ) {
                    stringBuilder.append(receiveString);
                }

                inputStream.close();
                ret = stringBuilder.toString();
            }

        }
        catch (FileNotFoundException e) {
            Log.e("login activity", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("login activity", "Can not read file: " + e.toString());
        }

        return ret;
    }

    public void writeToFile(String FILENAME, String data) {
        try {
            FileOutputStream fou = openFileOutput(FILENAME, MODE_PRIVATE);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fou);
            outputStreamWriter.write(data);
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
